# Literature Review (LangChain Version)

**Research Question:** What is LoRA in machine learning?

**Literature Review: Low-Rank Adaptation (LoRA) of Large Language Models**

Low-Rank Adaptation (LoRA) has emerged as a prominent parameter-efficient fine-tuning (PEFT) technique for adapting large language models (LLMs) to downstream tasks. The core idea behind LoRA, introduced by Hu et al. (2021), is to freeze the pre-trained model weights and inject trainable low-rank decomposition matrices into the layers of the Transformer architecture. This approach significantly reduces the number of trainable parameters, leading to memory savings and faster training times while maintaining or improving model performance compared to full fine-tuning.

**Key Concepts and Methodology:**

LoRA involves adding a low-rank matrix factorization to existing weight matrices in the Transformer architecture, typically the query and value projection matrices in the self-attention mechanism. The pre-trained weights are kept frozen, and only the low-rank matrices are trained. During a forward pass, the outputs of both the original and the low-rank adaptation are combined. This allows for efficient adaptation of LLMs to specific tasks without the computational burden of retraining the entire model.

**Improvements and Extensions:**

Several works have built upon the original LoRA framework to address its limitations and improve its performance. Wang et al. (2024) introduced LoRA-Pro, which adjusts the gradients of the low-rank matrices to better approximate the full fine-tuning gradient. Their analysis shows that LoRA optimization is mathematically equivalent to full fine-tuning with a low-rank gradient. By strategically adjusting the gradients of the low-rank matrices, LoRA-Pro can more effectively utilize the low-rank structure to capture relevant gradient information, leading to performance gains across various tasks.

**Theoretical Analysis and Convergence:**

Malinovsky et al. (2024) provided a theoretical analysis of LoRA and Chain of LoRA (CoLA), identifying convergence issues with these methods. They proposed Randomized Asymmetric Chain of LoRA (RAC-LoRA), a provably convergent method that incorporates randomization and asymmetry into the LoRA chain structure. RAC-LoRA offers guarantees to converge to the same solution as full-parameter fine-tuning, addressing the limitations of traditional LoRA and CoLA in terms of convergence and stability.

**Computational Efficiency:**

Hu et al. (2024) studied the computational limits of LoRA using fine-grained complexity theory. They demonstrated that the efficiency of LoRA fine-tuning depends on the norms of input data, pre-trained weights, and LoRA adaptation matrices. They identified a phase transition behavior in efficiency based on these norms and provided conditions for achieving almost linear time algorithms, opening up possibilities for scaling LoRA to even larger models and datasets.

**Bias Mitigation:**

Chang et al. (2024) addressed the problem of "Catastrophic Inheritance" in LoRA, where biases, noise, and data imbalances from pre-training can be exacerbated during fine-tuning. They introduced Bias-Alleviating Low-Rank Adaptation (BA-LoRA), which incorporates targeted regularizers to preserve core knowledge, enforce representational richness, and promote robust, low-rank output representations. BA-LoRA aims to mitigate bias and improve the fairness and robustness of LoRA-adapted models.

**Baselines and Prior Work:**

LoRA is often compared to full fine-tuning, adapter-based methods, and other parameter-efficient fine-tuning techniques. The original LoRA paper (Hu et al., 2021) demonstrated that LoRA performs on par or better than full fine-tuning on various tasks across different language models, despite using significantly fewer trainable parameters. Adapter-based methods, such as those explored by Houlsby et al. (2019), add small modules to the pre-trained model and train only these modules. Prefix-tuning (Li & Liang, 2021) prepends a sequence of trainable vectors to the input.

**Gaps in Existing Research:**

While LoRA has shown great promise, there are still gaps in existing research. Further investigation is needed into the optimization dynamics of LoRA and its variants, as well as the development of more robust and efficient algorithms for training LoRA models. Additionally, more research is needed to address the potential for bias amplification during LoRA fine-tuning and to develop effective techniques for mitigating these biases. The practical application of LoRA in different domains and the exploration of its limitations are also areas for future research.

**References:**

*   Chang, Y., Chang, Y., & Wu, Y. (2024). BA-LoRA: Bias-Alleviating Low-Rank Adaptation to Mitigate Catastrophic Inheritance in Large Language Models. *arXiv preprint arXiv:2408.04556*.
*   Hu, E. J., Shen, Y., Wallis, P., Allen-Zhu, Z., Li, Y., Wang, S., ... & Chen, W. (2021). LoRA: Low-Rank Adaptation of Large Language Models. *arXiv preprint arXiv:2106.09685*.
*   Hu, J. Y.-C., Su, M., Kuo, E.-J., Song, Z., & Liu, H. (2024). Computational Limits of Low-Rank Adaptation (LoRA) Fine-Tuning for Transformer Models. *arXiv preprint arXiv:2406.03136*.
*   Houlsby, N., Jastrzebski, S., Hessel, J., Strubell, E., Gopinath, A., & Davison, J. (2019). Parameter-Efficient Transfer Learning for NLP. *arXiv preprint arXiv:1902.00751*.
*   Li, X., & Liang, P. (2021). Prefix-Tuning: Optimizing Continuous Prompts for Generation. *arXiv preprint arXiv:2101.00114*.
*   Malinovsky, G., Michieli, U., Hammoud, H. A. K. A., Ceritli, T., Elesedy, H., Ozay, M., & Richt�rik, P. (2024). Randomized Asymmetric Chain of LoRA: The First Meaningful Theoretical Framework for Low-Rank Adaptation. *arXiv preprint arXiv:2410.08305*.
*   Wang, Z., Liang, J., He, R., Wang, Z., & Tan, T. (2024). LoRA-Pro: Are Low-Rank Adapters Properly Optimized?. *arXiv preprint arXiv:2407.18242*.