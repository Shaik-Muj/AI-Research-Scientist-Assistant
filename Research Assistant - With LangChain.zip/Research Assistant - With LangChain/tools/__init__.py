"""Tools package for the AI Research Scientist Agent."""
